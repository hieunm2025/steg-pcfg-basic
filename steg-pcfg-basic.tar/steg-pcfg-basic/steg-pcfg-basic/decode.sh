#!/bin/bash
# PCFG Steganography Detector and Decoder Script
# Phát hiện và giải mã thông tin ẩn từ văn bản
# Cải tiến: thêm xử lý lỗi, tùy chọn mở rộng và chức năng phân tích dữ liệu

set -e  # Dừng nếu có lỗi

# Mã màu cho output đẹp hơn
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Hàm in thông tin trợ giúp
print_help() {
    echo -e "${BLUE}PCFG STEGANOGRAPHY DETECTOR & DECODER${NC}"
    echo "Sử dụng: $0 <grammar_file> <text_file> [keys] [options]"
    echo
    echo "Tham số bắt buộc:"
    echo "    <grammar_file>: Tệp ngữ pháp PCFG"
    echo "    <text_file>: Tệp văn bản chứa thông tin ẩn"
    echo "    [keys]: Danh sách khóa có thể phân cách bởi dấu phẩy (mặc định: unknown)"
    echo
    echo "Tùy chọn:"
    echo "    -w, --wordlist FILE  Sử dụng tệp từ điển để hỗ trợ giải mã"
    echo "    -a, --analyze        Phân tích thêm tần suất chữ cái"
    echo "    -s, --statistics     Hiển thị thống kê chi tiết"
    echo "    -p, --plot FILE      Lưu biểu đồ tần suất chữ cái"
    echo "    -v, --verbose        Hiển thị thêm thông tin chi tiết"
    echo "    -h, --help           Hiển thị trợ giúp này"
    exit 1
}

# Hàm kiểm tra lệnh có tồn tại không
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Kiểm tra số tham số đầu vào
if [ "$#" -lt 2 ]; then
    echo -e "${RED}Lỗi: Thiếu tham số!${NC}"
    print_help
fi

# Biến mặc định
GRAMMAR_FILE="$1"
TEXT_FILE="$2"
KEYS="${3:-unknown}"
WORDLIST=""
ANALYZE=0
STATISTICS=0
PLOT_FILE=""
VERBOSE=0
TEMP_FILE=$(mktemp)

# Xử lý các tùy chọn
shift 2
if [ "$#" -gt 0 ]; then
    # Nếu tham số thứ 3 không bắt đầu với dấu '-', coi là khóa
    if [[ ! "$1" =~ ^- ]]; then
        shift
    fi

    while [ "$#" -gt 0 ]; do
        case "$1" in
            -w|--wordlist)
                WORDLIST="$2"
                shift 2
                ;;
            -a|--analyze)
                ANALYZE=1
                shift
                ;;
            -s|--statistics)
                STATISTICS=1
                shift
                ;;
            -p|--plot)
                PLOT_FILE="$2"
                shift 2
                ;;
            -v|--verbose)
                VERBOSE=1
                shift
                ;;
            -h|--help)
                print_help
                ;;
            *)
                echo -e "${RED}Lỗi: Tùy chọn không xác định: $1${NC}"
                print_help
                ;;
        esac
    done
fi

# Kiểm tra thư viện và công cụ cần thiết
if ! command_exists python3; then
    echo -e "${RED}Lỗi: Python 3 chưa được cài đặt!${NC}"
    exit 1
fi

if [ -n "$PLOT_FILE" ] && ! python3 -c "import matplotlib" 2>/dev/null; then
    echo -e "${YELLOW}Cảnh báo: Matplotlib không được cài đặt, không thể tạo biểu đồ.${NC}"
    PLOT_FILE=""
fi

# Kiểm tra tệp ngữ pháp và văn bản
if [ ! -f "$GRAMMAR_FILE" ]; then
    echo -e "${RED}Lỗi: Không tìm thấy tệp ngữ pháp '$GRAMMAR_FILE'!${NC}"
    exit 1
fi

if [ ! -f "$TEXT_FILE" ]; then
    echo -e "${RED}Lỗi: Không tìm thấy tệp văn bản '$TEXT_FILE'!${NC}"
    exit 1
fi

# Tạo tham số bổ sung
EXTRA_PARAMS=""

if [ -n "$WORDLIST" ]; then
    if [ ! -f "$WORDLIST" ]; then
        echo -e "${YELLOW}Cảnh báo: Không tìm thấy tệp từ điển '$WORDLIST', bỏ qua.${NC}"
    else
        EXTRA_PARAMS="$EXTRA_PARAMS --wordlist $WORDLIST"
    fi
fi

if [ $VERBOSE -eq 1 ]; then
    EXTRA_PARAMS="$EXTRA_PARAMS --verbose"
fi

# Thông báo bắt đầu
echo -e "${BLUE}=== PCFG STEGANOGRAPHY DETECTOR & DECODER ===${NC}"
echo -e "Tệp ngữ pháp: ${YELLOW}$GRAMMAR_FILE${NC}"
echo -e "Tệp văn bản:  ${YELLOW}$TEXT_FILE${NC}"
echo -e "Khóa:         ${YELLOW}$KEYS${NC}"

if [ -n "$WORDLIST" ] && [ -f "$WORDLIST" ]; then
    echo -e "Từ điển:     ${YELLOW}$WORDLIST${NC}"
fi

echo -e "${GREEN}Đang phát hiện và giải mã...${NC}"

# Chạy detector.py
if [ $VERBOSE -eq 1 ]; then
    python3 detector.py "$GRAMMAR_FILE" "$TEXT_FILE" --keys "$KEYS" $EXTRA_PARAMS
    DETECT_RESULT=$?
else
    python3 detector.py "$GRAMMAR_FILE" "$TEXT_FILE" --keys "$KEYS" $EXTRA_PARAMS > "$TEMP_FILE" 2>&1
    DETECT_RESULT=$?
    cat "$TEMP_FILE"
fi

# Nếu phát hiện thất bại
if [ $DETECT_RESULT -ne 0 ]; then
    echo -e "${RED}Lỗi khi chạy detector.py!${NC}"
    rm -f "$TEMP_FILE"
    exit 1
fi

# Phân tích văn bản nếu được yêu cầu
if [ $ANALYZE -eq 1 ]; then
    echo -e "\n${BLUE}=== PHÂN TÍCH VĂN BẢN ===${NC}"
    
    # Tạo lệnh phân tích
    ANALYZE_CMD="python3 analyze.py \"$TEXT_FILE\""
    
    # Thêm tùy chọn plot nếu có
    if [ -n "$PLOT_FILE" ]; then
        ANALYZE_CMD="$ANALYZE_CMD --plot=\"$PLOT_FILE\""
    fi
    
    # Chạy lệnh phân tích
    eval $ANALYZE_CMD
    
    # Kiểm tra kết quả
    if [ $? -ne 0 ]; then
        echo -e "${YELLOW}Cảnh báo: Phân tích văn bản không thành công!${NC}"
    elif [ -n "$PLOT_FILE" ] && [ -f "$PLOT_FILE" ]; then
        echo -e "Đã lưu biểu đồ tần suất vào '${BLUE}$PLOT_FILE${NC}'"
    fi
fi

# Hiển thị thống kê nếu được yêu cầu
if [ $STATISTICS -eq 1 ]; then
    echo -e "\n${BLUE}=== THỐNG KÊ TỆP ===${NC}"
    echo -e "Kích thước tệp:  $(wc -c < "$TEXT_FILE") byte"
    echo -e "Số dòng:         $(wc -l < "$TEXT_FILE")"
    echo -e "Số từ:           $(wc -w < "$TEXT_FILE")"
    
    # Tính entropy nếu có công cụ ent
    if command_exists ent; then
        ENTROPY=$(ent "$TEXT_FILE" 2>/dev/null | grep "Entropy" | awk '{print $3}' || echo "N/A")
        echo -e "Entropy:          $ENTROPY bits/byte"
    else
        # Tính entropy đơn giản nếu không có ent
        ENTROPY=$(python3 -c "
import sys, math
from collections import Counter
with open('$TEXT_FILE', 'rb') as f:
    data = f.read()
freqs = Counter(data)
total = len(data)
print(f'{-sum(count/total * math.log2(count/total) for count in freqs.values()):.3f}')
" 2>/dev/null || echo "N/A")
        echo -e "Entropy:          $ENTROPY bits/byte (ước tính)"
    fi
fi

# Xóa tệp tạm
rm -f "$TEMP_FILE"

echo -e "\n${GREEN}Hoàn tất phát hiện và giải mã!${NC}"
exit 0
