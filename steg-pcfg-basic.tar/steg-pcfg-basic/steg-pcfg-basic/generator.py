#!/usr/bin/env python3
"""
PCFG Steganography Encoder

Mã hóa thông điệp bí mật vào văn bản tự nhiên sử dụng ngữ pháp PCFG.
"""
import sys
import re
import random
import hashlib
import heapq
import logging
from collections import Counter

# Thiết lập logging
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

class PCFGSteganography:
    """
    Lớp thực hiện giấu tin dựa trên Probabilistic Context-Free Grammar (PCFG).
    """
    def __init__(self, grammar_file):
        """
        Khởi tạo đối tượng giấu tin PCFG.
        
        Args:
            grammar_file (str): Đường dẫn đến tệp ngữ pháp PCFG.
        """
        self.grammar = {}
        self.probabilities = {}
        self.static_texts = []
        self.huffman_codes_cache = {}
        self.load_grammar(grammar_file)
        
    def load_grammar(self, grammar_file):
        """
        Đọc và phân tích tệp ngữ pháp PCFG.
        
        Args:
            grammar_file (str): Đường dẫn đến tệp ngữ pháp PCFG.
        
        Raises:
            FileNotFoundError: Nếu không tìm thấy tệp ngữ pháp.
            ValueError: Nếu cú pháp ngữ pháp không hợp lệ.
        """
        try:
            with open(grammar_file, 'r', encoding='utf-8') as f:
                lines = f.readlines()
                
            current_symbol = None
            for line_num, line in enumerate(lines, 1):
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                    
                if '→' in line:
                    parts = line.split('→')
                    if len(parts) != 2:
                        raise ValueError(f"Lỗi cú pháp ở dòng {line_num}: {line}")
                        
                    current_symbol = parts[0].strip()
                    options_str = parts[1].strip()
                    options = []
                    probabilities = []
                    
                    for opt in options_str.split('||'):
                        opt = opt.strip()
                        if not opt:
                            continue
                            
                        opt_parts = opt.split('|')
                        if len(opt_parts) < 1:
                            raise ValueError(f"Lỗi cú pháp ở dòng {line_num}: {opt}")
                            
                        rule = opt_parts[0].strip()
                        
                        try:
                            prob = float(opt_parts[1].strip()) if len(opt_parts) > 1 else 1.0
                            if prob < 0 or prob > 1:
                                raise ValueError(f"Xác suất phải nằm trong khoảng [0, 1] ở dòng {line_num}")
                        except ValueError:
                            raise ValueError(f"Xác suất không hợp lệ ở dòng {line_num}: {opt_parts[1] if len(opt_parts) > 1 else '1.0'}")
                            
                        options.append(rule)
                        probabilities.append(prob)
                    
                    # Kiểm tra tổng xác suất
                    total_prob = sum(probabilities)
                    if abs(total_prob - 1.0) > 0.01 and len(options) > 1:  # Cho phép sai số nhỏ
                        logger.warning(f"Tổng xác suất cho {current_symbol} là {total_prob}, không bằng 1.0")
                        # Chuẩn hóa xác suất
                        probabilities = [p/total_prob for p in probabilities]
                    
                    self.grammar[current_symbol] = options
                    self.probabilities[current_symbol] = probabilities
                    
                    # Lưu static_text riêng để xử lý đặc biệt
                    if current_symbol == 'static_text':
                        self.static_texts.extend(options)
            
            # Kiểm tra tính hợp lệ của ngữ pháp
            if 'Start' not in self.grammar:
                raise ValueError("Ngữ pháp phải có biểu tượng 'Start'")
                
            logger.info(f"Đã tải ngữ pháp với {len(self.grammar)} biểu tượng không kết thúc")
            
        except FileNotFoundError:
            logger.error(f"Không tìm thấy tệp ngữ pháp: {grammar_file}")
            raise
        except Exception as e:
            logger.error(f"Lỗi khi tải ngữ pháp: {str(e)}")
            raise

    def enhance_grammar(self):
        """
        Tăng cường ngữ pháp để nâng cao khả năng mã hóa.
        
        Returns:
            bool: True nếu tăng cường thành công, False nếu không.
        """
        # Thêm nhiều biểu tượng không kết thúc và lựa chọn
        if 'ADJ' not in self.grammar:
            self.grammar['ADJ'] = ['great', 'excellent', 'prestigious', 'renowned', 
                                 'outstanding', 'remarkable', 'superior', 'exceptional']
            self.probabilities['ADJ'] = [0.125] * 8
        
        if 'NOUN' not in self.grammar:
            self.grammar['NOUN'] = ['programs', 'majors', 'courses', 'departments', 
                                  'faculties', 'disciplines', 'subjects', 'curricula']
            self.probabilities['NOUN'] = [0.125] * 8
        
        if 'CITY' not in self.grammar:
            self.grammar['CITY'] = ['Boston', 'London', 'Paris', 'Tokyo', 
                                  'Berlin', 'Sydney', 'Toronto', 'Madrid']
            self.probabilities['CITY'] = [0.125] * 8
        
        # Cập nhật Start
        if 'Start' in self.grammar:
            old_start = self.grammar['Start']
            # Thêm quy tắc mới với biểu tượng không kết thúc đã thêm
            new_start = old_start + ['CITY University offers ADJ NOUN for students.']
            self.grammar['Start'] = new_start
            self.probabilities['Start'] = [1.0/len(new_start)] * len(new_start)
        
        # Xóa bỏ cache mã Huffman để tạo lại
        self.huffman_codes_cache = {}
        
        logger.info(f"Đã tăng cường ngữ pháp với {len(self.grammar)} biểu tượng không kết thúc")
        return True

    def build_huffman_codes(self, symbol):
        """
        Xây dựng mã Huffman cho một biểu tượng không kết thúc.
        
        Args:
            symbol (str): Biểu tượng không kết thúc cần xây dựng mã Huffman.
            
        Returns:
            dict: Từ điển ánh xạ từ lựa chọn đến mã Huffman.
        """
        # Kiểm tra cache trước
        if symbol in self.huffman_codes_cache:
            return self.huffman_codes_cache[symbol]
            
        # Nếu chỉ có một lựa chọn, không cần mã hóa
        if len(self.grammar[symbol]) <= 1:
            self.huffman_codes_cache[symbol] = {self.grammar[symbol][0]: ''}
            return self.huffman_codes_cache[symbol]
            
        # Xây dựng heap cho thuật toán Huffman
        heap = [[prob, [opt, ""]] for opt, prob in zip(self.grammar[symbol], self.probabilities[symbol])]
        heapq.heapify(heap)
        
        # Thuật toán Huffman
        while len(heap) > 1:
            lo = heapq.heappop(heap)
            hi = heapq.heappop(heap)
            for pair in lo[1:]:
                pair[1] = '0' + pair[1]
            for pair in hi[1:]:
                pair[1] = '1' + pair[1]
            heapq.heappush(heap, [lo[0] + hi[0]] + lo[1:] + hi[1:])
        
        # Lưu kết quả vào cache
        result = {pair[0]: pair[1] for pair in heapq.heappop(heap)[1:]}
        self.huffman_codes_cache[symbol] = result
        return result

    def check_letter_frequency(self, text):
        """
        Kiểm tra tần suất xuất hiện của chữ cái trong văn bản để đảm bảo tính tự nhiên.
        
        Args:
            text (str): Văn bản cần kiểm tra.
            
        Returns:
            bool: True nếu tần suất tự nhiên, False nếu không.
        """
        from collections import Counter
        
        # Chỉ tính chữ cái
        freq = Counter(c.lower() for c in text if c.isalpha())
        total = sum(freq.values())
        
        # Nếu văn bản quá ngắn, coi là tự nhiên
        if total < 20:
            return True
            
        # Tần suất mong đợi của các chữ cái tiếng Anh (xấp xỉ)
        expected = {
            'e': 0.12, 't': 0.09, 'a': 0.08, 'o': 0.075, 'i': 0.07,
            'n': 0.067, 's': 0.063, 'h': 0.061, 'r': 0.06, 'd': 0.043,
            'l': 0.04, 'u': 0.028, 'c': 0.028, 'm': 0.025, 'w': 0.024,
            'f': 0.022, 'g': 0.02, 'y': 0.02, 'p': 0.019, 'b': 0.015,
            'v': 0.01, 'k': 0.008, 'j': 0.002, 'x': 0.002, 'q': 0.001, 'z': 0.001
        }
        
        # Kiểm tra các chữ cái quan trọng
        key_letters = ['e', 't', 'a', 'o', 'i', 'n', 's', 'z', 'q', 'x']
        for letter in key_letters:
            act_freq = freq.get(letter, 0) / total
            exp_freq = expected.get(letter, 0.01)
            # Cho phép sai lệch tối đa 50%
            if abs(act_freq - exp_freq) > 0.5 * exp_freq:
                return False
                
        return True

    def encode(self, binary_data, max_attempts=15, attempt=0):
        """
        Mã hóa thông điệp nhị phân thành văn bản sử dụng ngữ pháp PCFG.
        
        Args:
            binary_data (str): Chuỗi nhị phân cần mã hóa.
            max_attempts (int, optional): Số lần thử tối đa. Mặc định là 15.
            attempt (int, optional): Số lần đã thử. Mặc định là 0.
            
        Returns:
            str: Văn bản đã mã hóa.
        """
        if attempt >= max_attempts:
            logger.warning(f"Đã đạt số lần thử tối đa ({max_attempts}), trả về văn bản tốt nhất có thể")
            return '\n'.join(self.last_result) if hasattr(self, 'last_result') else "Không thể tạo văn bản phù hợp."
        
        result = []
        bit_index = 0
        sentence = []
        static_text_blocks = []
        
        # Bắt đầu từ biểu tượng Start
        stack = ['Start']
        processed_static_text = set()  # Theo dõi static_text đã xử lý
        
        while stack:
            symbol = stack.pop(0)
            
            # Xử lý biểu tượng kết thúc (từ)
            if symbol not in self.grammar:
                sentence.append(symbol)
                continue
                
            # Xử lý static_text đặc biệt
            if symbol == 'static_text':
                for static_text in self.static_texts:
                    if static_text not in processed_static_text:
                        processed_static_text.add(static_text)
                        # Thêm dấu chấm nếu là câu hoàn chỉnh và chưa có dấu
                        if static_text and not static_text.endswith(('.', '?', '!', ':')):
                            if static_text != 'These colleges and departments are:':
                                static_text_blocks.append(static_text + '.')
                            else:
                                static_text_blocks.append(static_text)
                        else:
                            static_text_blocks.append(static_text)
                continue
                
            # Lấy các lựa chọn và xác suất
            options = self.grammar[symbol]
            
            # Nếu chỉ có một lựa chọn, không cần mã hóa bit
            if len(options) == 1:
                selected = options[0]
                stack = selected.split() + stack
                continue
                
            # Tạo mã Huffman cho biểu tượng hiện tại
            huffman_codes = self.build_huffman_codes(symbol)
            
            # Cố gắng mã hóa bit nếu còn bit để mã hóa
            encoded = False
            if bit_index < len(binary_data):
                # Tìm lựa chọn phù hợp với bit tiếp theo
                for opt, code in huffman_codes.items():
                    if code and bit_index + len(code) <= len(binary_data):
                        if binary_data[bit_index:bit_index+len(code)] == code:
                            selected = opt
                            bit_index += len(code)
                            encoded = True
                            break
            
            # Nếu không thể mã hóa, chọn ngẫu nhiên theo xác suất
            if not encoded:
                selected = random.choices(options, weights=self.probabilities[symbol])[0]
                
            # Đẩy các từ của lựa chọn vào stack để xử lý tiếp
            stack = selected.split() + stack
        
        # Kết hợp từ thành câu với định dạng đúng
        text = ' '.join(word.capitalize() if word.lower() in ['university', 'zhonghua', 'it'] else word for word in sentence)
        
        # Thêm dấu chấm cho câu nếu cần
        if text and not text.endswith(('.', '?', '!', ':')):
            text += '.'
            
        result.append(text)
        
        # Thêm các static_text vào kết quả
        if static_text_blocks:
            result.append('\n'.join(static_text_blocks))
            
        # Lưu kết quả hiện tại để sử dụng nếu đạt số lần thử tối đa
        self.last_result = result
        
        # Kiểm tra tính tự nhiên của văn bản và thử lại nếu cần
        combined_text = '\n'.join(result)
        if self.check_letter_frequency(combined_text):
            logger.info(f"Đã mã hóa thành công {bit_index} bit trên tổng số {len(binary_data)} bit")
            return combined_text
        else:
            logger.info(f"Lần thử {attempt + 1}: Tần suất chữ cái không tự nhiên, thử lại")
            return self.encode(binary_data, max_attempts, attempt + 1)

    def str_to_binary(self, message, key, bits=96):
        """
        Chuyển đổi thông điệp thành chuỗi nhị phân sử dụng hàm băm kết hợp với khóa.
        
        Args:
            message (str): Thông điệp cần mã hóa.
            key (str): Khóa bí mật.
            bits (int, optional): Số bit đầu ra. Mặc định là 96.
            
        Returns:
            str: Chuỗi nhị phân.
        """
        # Kết hợp thông điệp và khóa, băm bằng SHA-256
        h = hashlib.sha256((message + key).encode()).hexdigest()
        # Chuyển đổi giá trị băm thành nhị phân
        binary = bin(int(h, 16))[2:]
        # Cắt để đảm bảo độ dài cố định
        return binary.zfill(bits)[:bits]

def main():
    """Hàm chính điều khiển luồng chương trình."""
    if len(sys.argv) < 4:
        print("Sử dụng: python generator.py <grammar_file> <secret_message> <key> [bits] [--enhance]")
        return 1
        
    try:
        grammar_file = sys.argv[1]
        secret_message = sys.argv[2]
        key = sys.argv[3]
        
        # Xử lý các tham số tùy chọn
        bits = 96
        enhance = False
        
        for i in range(4, len(sys.argv)):
            if sys.argv[i] == '--enhance':
                enhance = True
            elif sys.argv[i].isdigit():
                bits = int(sys.argv[i])
        
        steg = PCFGSteganography(grammar_file)
        
        # Tăng cường ngữ pháp nếu cần
        if enhance:
            logger.info("Tăng cường ngữ pháp để nâng cao khả năng mã hóa...")
            steg.enhance_grammar()
        
        # Tính toán khả năng mã hóa
        bit_count = 0
        for symbol, options in steg.grammar.items():
            if len(options) > 1 and symbol != 'static_text':
                bit_count += len(options).bit_length() - 1
        
        # Chuyển đổi thông điệp thành chuỗi nhị phân
        binary_data = steg.str_to_binary(secret_message, key, bits)
        
        print(f"Biểu diễn nhị phân của thông điệp bí mật ({bits} bits):")
        print(binary_data)
        
        # Mã hóa thông điệp
        encoded_text = steg.encode(binary_data)
        
        print("\nVăn bản mã hóa:")
        print(encoded_text)
        
        # Hiển thị thông tin khả năng mã hóa
        print(f"\nThông tin khả năng mã hóa:")
        print(f"- Số bit tối đa có thể mã hóa: {bit_count}")
        print(f"- Số bit đã cố gắng mã hóa: {bits}")
        
        return 0
        
    except Exception as e:
        logger.error(f"Lỗi: {str(e)}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
