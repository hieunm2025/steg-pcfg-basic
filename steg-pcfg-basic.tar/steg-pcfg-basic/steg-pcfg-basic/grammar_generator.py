#!/usr/bin/env python3
"""
PCFG Grammar Generator

This module generates Probabilistic Context-Free Grammar (PCFG) from input text
for use in steganography applications. It extracts patterns and builds grammar rules
with proper probabilities.
"""

import sys
import re
import random
import logging
import argparse
from collections import Counter, defaultdict
from typing import Dict, List, Tuple, Set, Optional, Union, Any

# Setup logging with proper format
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

class GrammarGenerator:
    """
    Class for generating PCFG grammar from input text.
    """
    def __init__(self, text: Optional[str] = None):
        """
        Initialize the grammar generator.
        
        Args:
            text: Input text (optional).
        """
        self.text = text
        self.tokens: List[str] = []
        self.word_freq = Counter()
        self.pos_tags: List[Tuple[str, str]] = []
        self.grammar: Dict[str, List[Tuple[str, float]]] = {}
        
        # Try to load NLTK if needed
        try:
            import nltk
            nltk.download('punkt', quiet=True)
            nltk.download('averaged_perceptron_tagger', quiet=True)
            self.nltk_available = True
        except ImportError:
            logger.warning("NLTK not installed. Basic grammar generation mode will be used.")
            self.nltk_available = False
            
    def load_from_file(self, filename: str) -> None:
        """
        Read text from file.
        
        Args:
            filename: Path to text file.
            
        Raises:
            FileNotFoundError: If the file is not found.
        """
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                self.text = f.read()
            logger.info(f"Loaded text from {filename}, length: {len(self.text)} characters")
        except UnicodeDecodeError:
            logger.warning(f"UTF-8 encoding error, trying again with Latin-1")
            with open(filename, 'r', encoding='latin-1') as f:
                self.text = f.read()
        except FileNotFoundError:
            logger.error(f"File not found: {filename}")
            raise
    
    def preprocess_text(self) -> None:
        """
        Preprocess text: segment, tokenize, POS-tag.
        """
        if not self.text:
            logger.warning("No text to process.")
            return
            
        # Split into sentences and words
        if self.nltk_available:
            try:
                import nltk
                sentences = nltk.sent_tokenize(self.text)
                self.tokens = []
                for sentence in sentences:
                    self.tokens.extend(nltk.word_tokenize(sentence))
                    
                # Count word frequency
                self.word_freq = Counter(self.tokens)
                
                # POS tagging
                self.pos_tags = nltk.pos_tag(self.tokens)
                
                logger.info(f"Processed {len(sentences)} sentences, {len(self.tokens)} words.")
                
            except Exception as e:
                logger.error(f"Error preprocessing text: {str(e)}")
                # Use simpler method
                self.tokens = re.findall(r'\b\w+\b', self.text)
                self.word_freq = Counter(self.tokens)
                logger.info(f"Processed {len(self.tokens)} words (simple method).")
        else:
            # Simple tokenization if NLTK is not available
            self.tokens = re.findall(r'\b\w+\b', self.text)
            self.word_freq = Counter(self.tokens)
            logger.info(f"Processed {len(self.tokens)} words (without NLTK).")
    
    def extract_patterns(self) -> None:
        """
        Extract patterns from text to build grammar.
        """
        if not self.tokens:
            self.preprocess_text()
            
        if not self.tokens:
            logger.warning("No words to extract patterns from.")
            return
            
        # Group words by POS tag (if POS tagged)
        pos_groups = defaultdict(list)
        if self.pos_tags and self.nltk_available:
            for word, pos in self.pos_tags:
                pos_groups[pos].append(word)
        else:
            # Simple classification if no POS tagging
            for word in self.tokens:
                if word.lower() in ['a', 'an', 'the']:
                    pos_groups['DT'].append(word)
                elif word.lower() in ['in', 'on', 'at', 'with', 'by', 'for', 'of']:
                    pos_groups['IN'].append(word)
                elif word.lower() in ['is', 'are', 'was', 'were', 'be', 'been', 'being']:
                    pos_groups['VB'].append(word)
                elif any(char.isdigit() for char in word):
                    pos_groups['CD'].append(word)
                else:
                    pos_groups['NN'].append(word)
        
        # Create non-terminal symbols based on POS
        grammar_symbols = {
            'DT': 'DET',  # Determiners
            'JJ': 'ADJ',  # Adjectives
            'NN': 'NOUN', # Nouns
            'NNS': 'NOUNS', # Plural nouns
            'VB': 'VERB', # Verbs
            'VBZ': 'VERBS', # 3rd person singular verbs
            'IN': 'PREP', # Prepositions
            'RB': 'ADV',  # Adverbs
            'CD': 'NUM'   # Numbers
        }
        
        # Filter and keep POS groups with at least 4 different words
        valid_pos = {}
        for pos, words in pos_groups.items():
            unique_words = set(words)
            if len(unique_words) >= 4:
                # Take up to 8 most common words
                common_words = [word for word, _ in Counter(words).most_common(8)]
                valid_pos[pos] = common_words
                
        # Create non-terminal symbols and rules
        self.grammar = {}
        symbol_count = 1
        for pos, words in valid_pos.items():
            symbol = grammar_symbols.get(pos, f"SYM{symbol_count}")
            symbol_count += 1
            
            # Calculate probabilities based on frequency
            total_count = sum(self.word_freq[word] for word in words)
            rule_probs = [(word, self.word_freq[word] / total_count) for word in words]
            
            # Store in grammar
            self.grammar[symbol] = rule_probs
        
        # Extract sentence patterns from text
        self.extract_sentence_patterns()
        
        logger.info(f"Created {len(self.grammar)} non-terminal symbols.")
    
    def extract_sentence_patterns(self) -> None:
        """
        Extract sentence patterns from text.
        """
        if not self.text:
            return
            
        try:
            # Split text into sentences
            if self.nltk_available:
                import nltk
                sentences = nltk.sent_tokenize(self.text)
            else:
                # Simple sentence splitting if NLTK not available
                sentences = re.split(r'[.!?]+', self.text)
                sentences = [s.strip() for s in sentences if s.strip()]
                
            if sentences:
                # Choose some random sentences as templates
                sample_sentences = random.sample(sentences, min(3, len(sentences)))
                
                # Add sentence patterns to grammar
                self.grammar['Start'] = []
                for i, sentence in enumerate(sample_sentences, 1):
                    # Replace words with non-terminal symbols
                    pattern = sentence
                    for symbol, rule_probs in self.grammar.items():
                        if symbol != 'Start':
                            for word, _ in rule_probs:
                                pattern = re.sub(r'\b' + re.escape(word) + r'\b', symbol, pattern, flags=re.IGNORECASE)
                    
                    # Normalize pattern
                    pattern = re.sub(r'\s+', ' ', pattern).strip()
                    self.grammar['Start'].append((pattern, 1.0 / len(sample_sentences)))
        except Exception as e:
            logger.error(f"Error extracting sentence patterns: {str(e)}")
            # Create simple sentence pattern if error
            if self.grammar:
                self.grammar['Start'] = [("This is a NOUN with many ADJ features.", 1.0)]
    
    def generate_grammar(self) -> str:
        """
        Generate full PCFG grammar.
        
        Returns:
            String representation of PCFG grammar.
        """
        if not self.grammar:
            self.extract_patterns()
            
        if not self.grammar:
            # Create basic grammar if can't generate from text
            self.grammar = {
                'ADJ': [('beautiful', 0.25), ('comprehensive', 0.25), ('famous', 0.25), ('prestigious', 0.25)],
                'NOUN': [('majors', 0.25), ('disciplines', 0.25), ('programs', 0.25), ('fields', 0.25)],
                'Start': [('Zhonghua University is a ADJ university with many NOUN.', 1.0)]
            }
            
        # Convert grammar to string
        grammar_str = []
        
        # Output Start symbol first
        if 'Start' in self.grammar:
            rule_str = "Start → " + " || ".join([f"{option} | {prob:.2f}" for option, prob in self.grammar['Start']])
            grammar_str.append(rule_str)
            
        # Output other symbols
        for symbol, rule_probs in self.grammar.items():
            if symbol != 'Start':
                rule_str = f"{symbol} → " + " || ".join([f"{option} | {prob:.2f}" for option, prob in rule_probs])
                grammar_str.append(rule_str)
                
        # Add static_text if present in text
        if self.text:
            sentences = re.split(r'[.!?]+', self.text)
            static_texts = [sentence.strip() for sentence in sentences if sentence.strip()]
            if static_texts:
                for i, text in enumerate(static_texts[:3]):  # Only take first 3 sentences as static_text
                    grammar_str.append(f"static_text → {text} | 1.0")
                
        return "\n".join(grammar_str)
    
    def save_to_file(self, filename: str) -> bool:
        """
        Save PCFG grammar to file.
        
        Args:
            filename: Path to output file.
            
        Returns:
            True if successful, False if failed.
        """
        try:
            grammar_str = self.generate_grammar()
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(grammar_str)
            logger.info(f"Saved grammar to {filename}")
            return True
        except Exception as e:
            logger.error(f"Error saving grammar: {str(e)}")
            return False
    
    def print_grammar(self) -> None:
        """
        Print PCFG grammar to console.
        """
        grammar_str = self.generate_grammar()
        print(grammar_str)
        
    def get_grammar_info(self) -> Dict[str, int]:
        """
        Return information about the generated grammar.
        
        Returns:
            Dictionary with grammar information.
        """
        if not self.grammar:
            return {"symbols": 0, "rules": 0, "bits": 0}
            
        symbols = len(self.grammar)
        rules = sum(len(rule_probs) for rule_probs in self.grammar.values())
        
        # Calculate encodable bits
        bits = 0
        for symbol, rule_probs in self.grammar.items():
            if len(rule_probs) > 1:
                bits += len(rule_probs).bit_length() - 1
                
        return {"symbols": symbols, "rules": rules, "bits": bits}


def main() -> int:
    """Main function with command-line argument parsing."""
    parser = argparse.ArgumentParser(description="Generate PCFG grammar from text for steganography.")
    parser.add_argument("text_file", help="Path to input text file")
    parser.add_argument("-o", "--output", help="Output grammar file (default: print to stdout)")
    parser.add_argument("-v", "--verbose", action="store_true", help="Enable verbose output")
    
    if len(sys.argv) == 1:
        parser.print_help()
        return 1
        
    try:
        args = parser.parse_args()
        
        # Set logging level based on verbosity
        if args.verbose:
            logging.getLogger().setLevel(logging.DEBUG)
        
        generator = GrammarGenerator()
        generator.load_from_file(args.text_file)
        generator.extract_patterns()
        
        grammar_info = generator.get_grammar_info()
        print(f"=== GRAMMAR INFORMATION ===")
        print(f"Non-terminal symbols: {grammar_info['symbols']}")
        print(f"Production rules: {grammar_info['rules']}")
        print(f"Encodable bits: {grammar_info['bits']}")
        print()
        
        if args.output:
            generator.save_to_file(args.output)
        else:
            generator.print_grammar()
            
        return 0
        
    except FileNotFoundError as e:
        print(f"Error: {str(e)}")
        return 1
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        if args.verbose:
            import traceback
            logger.error(traceback.format_exc())
        return 1


if __name__ == "__main__":
    sys.exit(main())
