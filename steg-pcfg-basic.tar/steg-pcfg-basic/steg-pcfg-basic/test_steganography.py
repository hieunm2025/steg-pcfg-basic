#!/usr/bin/env python3
"""
Script kiểm tra tự động hệ thống PCFG steganography.
Kiểm tra tất cả các chức năng chính của hệ thống.
"""

import os
import sys
import time
import logging
import subprocess
import random
import string
import tempfile
import argparse

# Thiết lập logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

class SteganographyTester:
    """
    Lớp kiểm tra tự động hệ thống steganography PCFG.
    """
    def __init__(self, verbose=False):
        """
        Khởi tạo đối tượng kiểm tra.
        
        Args:
            verbose (bool): Hiển thị thông tin chi tiết.
        """
        self.verbose = verbose
        self.temp_files = []
        
        # Cấu hình
        self.default_grammar = "grammar.pcfg"
        self.test_grammar = "test_grammar.pcfg"
        self.output_dir = "test_output"
        self.success_count = 0
        self.fail_count = 0
        
        # Đảm bảo thư mục đầu ra tồn tại
        os.makedirs(self.output_dir, exist_ok=True)
        
    def create_test_grammar(self):
        """
        Tạo ngữ pháp PCFG đơn giản để kiểm tra.
        
        Returns:
            str: Đường dẫn đến tệp ngữ pháp.
        """
        grammar_content = """
Start → S1 S2 S3 S4 | 1.0
S1 → Test university | 1.0
S2 → is A1 | 1.0
S3 → with many N1 | 1.0
S4 → in D1 | 1.0
A1 → famous | 0.25 || prestigious | 0.25 || beautiful | 0.25 || excellent | 0.25
N1 → students | 0.25 || professors | 0.25 || courses | 0.25 || buildings | 0.25
D1 → Asia | 0.25 || Europe | 0.25 || America | 0.25 || Africa | 0.25
static_text → This is a test grammar. | 1.0
"""
        output_path = os.path.join(self.output_dir, self.test_grammar)
        with open(output_path, "w") as f:
            f.write(grammar_content)
        logger.info(f"Đã tạo ngữ pháp kiểm tra: {output_path}")
        return output_path
        
    def run_command(self, command):
        """
        Chạy lệnh shell và trả về kết quả.
        
        Args:
            command (str): Lệnh cần chạy.
            
        Returns:
            tuple: (success, output)
                - success (bool): True nếu lệnh chạy thành công, False nếu không.
                - output (str): Đầu ra từ lệnh.
        """
        try:
            if self.verbose:
                logger.info(f"Chạy lệnh: {command}")
            result = subprocess.run(
                command, 
                shell=True,
                capture_output=True,
                text=True,
                check=False
            )
            success = result.returncode == 0
            output = result.stdout
            if not success:
                logger.error(f"Lỗi: {result.stderr}")
            return success, output
        except Exception as e:
            logger.error(f"Lỗi khi chạy lệnh '{command}': {str(e)}")
            return False, str(e)
            
    def generate_random_message(self, length=10):
        """
        Tạo thông điệp ngẫu nhiên.
        
        Args:
            length (int): Độ dài thông điệp.
            
        Returns:
            str: Thông điệp ngẫu nhiên.
        """
        return ''.join(random.choices(string.ascii_letters + string.digits, k=length))
        
    def run_test(self, test_name, command, expected_output=None, check_file=None):
        """
        Chạy một kiểm tra đơn.
        
        Args:
            test_name (str): Tên kiểm tra.
            command (str): Lệnh kiểm tra.
            expected_output (str, optional): Chuỗi mong đợi trong đầu ra.
            check_file (str, optional): Tệp cần kiểm tra sự tồn tại.
            
        Returns:
            bool: True nếu kiểm tra thành công, False nếu không.
        """
        logger.info(f"Kiểm tra: {test_name}")
        
        start_time = time.time()
        success, output = self.run_command(command)
        
        if not success:
            logger.error(f"Kiểm tra thất bại: {test_name}")
            self.fail_count += 1
            return False
            
        if expected_output and expected_output not in output:
            logger.error(f"Kiểm tra thất bại: Không tìm thấy '{expected_output}' trong đầu ra")
            self.fail_count += 1
            return False
            
        if check_file and not os.path.exists(check_file):
            logger.error(f"Kiểm tra thất bại: Không tìm thấy tệp '{check_file}'")
            self.fail_count += 1
            return False
            
        elapsed_time = time.time() - start_time
        logger.info(f"Kiểm tra thành công: {test_name} ({elapsed_time:.2f}s)")
        self.success_count += 1
        return True
        
    def run_all_tests(self):
        """
        Chạy tất cả các kiểm tra.
        
        Returns:
            tuple: (success_count, fail_count)
        """
        logger.info("=== BẮT ĐẦU KIỂM TRA TỰ ĐỘNG ===")
        
        # Tạo ngữ pháp kiểm tra
        test_grammar = self.create_test_grammar()
        
        # Tạo thông điệp và khóa ngẫu nhiên
        test_message = self.generate_random_message()
        test_key = self.generate_random_message(5)
        encoded_file = os.path.join(self.output_dir, "encoded_test.txt")
        
        # Kiểm tra 1: Mã hóa
        self.run_test(
            "Mã hóa thông điệp",
            f"./encode.sh '{test_message}' '{test_key}' -g {self.default_grammar} -o {encoded_file}",
            "Mã hóa thành công",
            encoded_file
        )
        
        # Kiểm tra 2: Giải mã
        self.run_test(
            "Giải mã thông điệp",
            f"./decode.sh {self.default_grammar} {encoded_file} '{test_key}'",
            "Đã phát hiện thông tin ẩn"
        )
        
        # Kiểm tra 3: Tạo ngữ pháp từ văn bản
        custom_grammar = os.path.join(self.output_dir, "custom_grammar.pcfg")
        self.run_test(
            "Tạo ngữ pháp từ văn bản",
            f"python3 grammar_generator.py {encoded_file} {custom_grammar}",
            "Số biểu tượng không kết thúc",
            custom_grammar
        )
        
        # Kiểm tra 4: Mã hóa với ngữ pháp tùy chỉnh
        custom_encoded = os.path.join(self.output_dir, "custom_encoded.txt")
        self.run_test(
            "Mã hóa với ngữ pháp tùy chỉnh",
            f"./encode.sh '{test_message}' '{test_key}' -g {test_grammar} -o {custom_encoded}",
            "Mã hóa thành công",
            custom_encoded
        )
        
        # Kiểm tra 5: Phân tích văn bản
        self.run_test(
            "Phân tích văn bản",
            f"python3 analyze.py {encoded_file}",
            "Tần suất chữ cái"
        )
        
        # Kiểm tra 6: Chạy tất cả các tùy chọn
        self.run_test(
            "Tùy chọn mở rộng",
            f"./decode.sh {self.default_grammar} {encoded_file} '{test_key}' -a -s",
            "PHÂN TÍCH VĂN BẢN"
        )
        
        # Thống kê kết quả
        logger.info("\n=== KẾT QUẢ KIỂM TRA ===")
        logger.info(f"Tổng số kiểm tra: {self.success_count + self.fail_count}")
        logger.info(f"Thành công: {self.success_count}")
        logger.info(f"Thất bại: {self.fail_count}")
        
        return self.success_count, self.fail_count
        
    def cleanup(self):
        """
        Dọn dẹp các tệp tạm thời.
        """
        if self.verbose:
            logger.info("Đang dọn dẹp tệp tạm thời...")
        for temp_file in self.temp_files:
            if os.path.exists(temp_file):
                os.remove(temp_file)

def main():
    """Hàm chính điều khiển luồng chương trình."""
    parser = argparse.ArgumentParser(description="Kiểm tra tự động hệ thống PCFG steganography.")
    parser.add_argument("-v", "--verbose", action="store_true", help="Hiển thị thông tin chi tiết")
    parser.add_argument("-c", "--cleanup", action="store_true", help="Xóa tệp tạm thời sau khi kiểm tra")
    args = parser.parse_args()
    
    tester = SteganographyTester(verbose=args.verbose)
    
    try:
        success_count, fail_count = tester.run_all_tests()
        if args.cleanup:
            tester.cleanup()
        
        # Trả về mã thoát dựa trên kết quả
        return 1 if fail_count > 0 else 0
        
    except KeyboardInterrupt:
        logger.info("Đã dừng kiểm tra theo yêu cầu người dùng")
        return 130
    except Exception as e:
        logger.error(f"Lỗi không mong đợi: {str(e)}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
