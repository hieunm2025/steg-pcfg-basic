#!/bin/bash
# Script mã hóa thông điệp bí mật sử dụng PCFG steganography
# Cải tiến: thêm xử lý lỗi, tùy chọn tăng cường và phân tích

set -e  # Dừng nếu có lỗi

# Mã màu cho output đẹp hơn
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Hàm in thông tin trợ giúp
print_help() {
    echo -e "${BLUE}PCFG STEGANOGRAPHY ENCODER${NC}"
    echo "Sử dụng: $0 <secret_message> <key> [options]"
    echo
    echo "Tham số bắt buộc:"
    echo "    <secret_message>: Thông điệp bí mật cần mã hóa"
    echo "    <key>: Khóa bí mật để mã hóa"
    echo
    echo "Tùy chọn:"
    echo "    -g, --grammar FILE   Chỉ định tệp ngữ pháp PCFG (mặc định: grammar.pcfg)"
    echo "    -o, --output FILE    Chỉ định tệp đầu ra (mặc định: encoded_text.txt)"
    echo "    -b, --bits NUMBER    Chỉ định số bit mã hóa (mặc định: 96)"
    echo "    -e, --enhance        Tự động tăng cường ngữ pháp để nâng cao khả năng mã hóa"
    echo "    -a, --analyze        Phân tích văn bản sau khi mã hóa"
    echo "    -v, --verbose        Hiển thị thêm thông tin chi tiết"
    echo "    -h, --help           Hiển thị trợ giúp này"
    exit 1
}

# Hàm kiểm tra lệnh có tồn tại không
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Kiểm tra số tham số đầu vào
if [ "$#" -lt 2 ]; then
    echo -e "${RED}Lỗi: Thiếu tham số!${NC}"
    print_help
fi

# Biến mặc định
SECRET="$1"
KEY="$2"
GRAMMAR_FILE="grammar.pcfg"
OUTPUT_FILE="encoded_text.txt"
BITS=96
VERBOSE=0
ANALYZE=0
ENHANCE=0
TEMP_FILE=$(mktemp)

# Xử lý các tùy chọn
shift 2
while [ "$#" -gt 0 ]; do
    case "$1" in
        -g|--grammar)
            GRAMMAR_FILE="$2"
            shift 2
            ;;
        -o|--output)
            OUTPUT_FILE="$2"
            shift 2
            ;;
        -b|--bits)
            BITS="$2"
            if ! [[ "$BITS" =~ ^[0-9]+$ ]]; then
                echo -e "${RED}Lỗi: Bits phải là số nguyên dương.${NC}"
                exit 1
            fi
            shift 2
            ;;
        -e|--enhance)
            ENHANCE=1
            shift
            ;;
        -a|--analyze)
            ANALYZE=1
            shift
            ;;
        -v|--verbose)
            VERBOSE=1
            shift
            ;;
        -h|--help)
            print_help
            ;;
        *)
            echo -e "${RED}Lỗi: Tùy chọn không xác định: $1${NC}"
            print_help
            ;;
    esac
done

# Kiểm tra thư viện và công cụ cần thiết
if ! command_exists python3; then
    echo -e "${RED}Lỗi: Python 3 chưa được cài đặt!${NC}"
    exit 1
fi

# Kiểm tra tệp ngữ pháp
if [ ! -f "$GRAMMAR_FILE" ]; then
    echo -e "${RED}Lỗi: Không tìm thấy tệp ngữ pháp '$GRAMMAR_FILE'!${NC}"
    echo "Đảm bảo rằng tệp tồn tại hoặc chỉ định tệp khác với tùy chọn -g"
    exit 1
fi

# Thông báo bắt đầu
echo -e "${BLUE}=== PCFG STEGANOGRAPHY ENCODER ===${NC}"
echo -e "Tệp ngữ pháp:  ${YELLOW}$GRAMMAR_FILE${NC}"
echo -e "Thông điệp:    ${YELLOW}$SECRET${NC}"
echo -e "Số bit mã hóa: ${YELLOW}$BITS${NC}"
echo -e "Tệp đầu ra:    ${YELLOW}$OUTPUT_FILE${NC}"

# Tạo tham số mở rộng
EXTRA_PARAMS=""
if [ $ENHANCE -eq 1 ]; then
    echo -e "${GREEN}Đang tăng cường ngữ pháp để nâng cao khả năng mã hóa...${NC}"
    EXTRA_PARAMS="$EXTRA_PARAMS --enhance"
fi

echo -e "${GREEN}Đang mã hóa...${NC}"

# Chạy generator.py với các tham số
if [ $VERBOSE -eq 1 ]; then
    python3 generator.py "$GRAMMAR_FILE" "$SECRET" "$KEY" "$BITS" $EXTRA_PARAMS
    RESULT=$?
else
    python3 generator.py "$GRAMMAR_FILE" "$SECRET" "$KEY" "$BITS" $EXTRA_PARAMS > "$TEMP_FILE" 2>&1
    RESULT=$?
fi

# Kiểm tra kết quả
if [ $RESULT -ne 0 ]; then
    echo -e "${RED}Lỗi: Không thể chạy generator.py!${NC}"
    if [ $VERBOSE -eq 0 ]; then
        echo "Chi tiết lỗi:"
        cat "$TEMP_FILE"
    fi
    rm -f "$TEMP_FILE"
    exit 1
fi

# Trích xuất văn bản mã hóa từ kết quả
if [ $VERBOSE -eq 0 ]; then
    # Lấy phần văn bản mã hóa
    sed -n '/Văn bản mã hóa:/,/Thông tin khả năng mã hóa:/ p' "$TEMP_FILE" | 
        sed '1d;$d' > "$OUTPUT_FILE"
    
    # Kiểm tra nếu tệp đầu ra có nội dung
    if [ ! -s "$OUTPUT_FILE" ]; then
        echo -e "${RED}Lỗi: Không thể trích xuất văn bản đã mã hóa!${NC}"
        cat "$TEMP_FILE"
        rm -f "$TEMP_FILE"
        exit 1
    fi
    
    # Lấy thông tin bitstream và thông tin khả năng mã hóa
    BINARY_DATA=$(grep "Biểu diễn nhị phân" "$TEMP_FILE" -A 1 | tail -n 1)
    CAPACITY=$(grep "Số bit tối đa có thể mã hóa:" "$TEMP_FILE" | cut -d ':' -f 2 | tr -d ' ')
    
    echo -e "${GREEN}Mã hóa thành công!${NC}"
    echo -e "Biểu diễn nhị phân: ${YELLOW}$BINARY_DATA${NC}"
    
    if [ -n "$CAPACITY" ]; then
        echo -e "Khả năng mã hóa tối đa: ${GREEN}$CAPACITY bit${NC}"
        if [ "$CAPACITY" -lt "$BITS" ] && [ $ENHANCE -eq 0 ]; then
            echo -e "${YELLOW}Cảnh báo:${NC} Ngữ pháp hiện tại không đủ khả năng để mã hóa $BITS bit."
            echo -e "Hãy sử dụng tùy chọn ${GREEN}-e/--enhance${NC} để tăng cường ngữ pháp."
        fi
    fi
    
    echo -e "Văn bản đã mã hóa được lưu vào '${BLUE}$OUTPUT_FILE${NC}'"
    echo -e "Để giải mã, sử dụng: ${GREEN}./decode.sh $GRAMMAR_FILE $OUTPUT_FILE \"$KEY\"${NC}"
    
    # Phân tích văn bản nếu được yêu cầu
    if [ $ANALYZE -eq 1 ]; then
        echo -e "\n${BLUE}=== PHÂN TÍCH VĂN BẢN ===${NC}"
        python3 analyze.py "$OUTPUT_FILE"
        if [ $? -ne 0 ]; then
            echo -e "${YELLOW}Cảnh báo: Phân tích văn bản không thành công!${NC}"
        fi
    fi
fi

# Xóa tệp tạm thời
if [ -f "$TEMP_FILE" ]; then
    rm -f "$TEMP_FILE"
fi

exit 0
