#!/usr/bin/env python3
"""
Công cụ phân tích văn bản

Phân tích thống kê văn bản để phục vụ steganalysis.
"""
import sys
import argparse
import math
from collections import Counter
import matplotlib.pyplot as plt

def calculate_entropy(text):
    """
    Tính entropy Shannon của văn bản.
    
    Args:
        text (str): Văn bản cần phân tích.
        
    Returns:
        float: Giá trị entropy (bit trên ký tự).
    """
    # Tính tần suất của mỗi ký tự
    freq = Counter(text)
    total = sum(freq.values())
    
    # Tính entropy
    entropy = 0
    for count in freq.values():
        prob = count / total
        entropy -= prob * math.log2(prob)
        
    return entropy

def analyze_letter_frequency(text):
    """
    Phân tích tần suất chữ cái trong văn bản.
    
    Args:
        text (str): Văn bản cần phân tích.
        
    Returns:
        tuple: (letter_freq, word_freq)
            - letter_freq: Từ điển tần suất chữ cái.
            - word_freq: Từ điển tần suất từ.
    """
    # Chuyển văn bản thành chữ thường
    text = text.lower()
    
    # Tính tần suất chữ cái
    letter_freq = Counter(c for c in text if c.isalpha())
    total_letters = sum(letter_freq.values())
    
    if total_letters == 0:
        return {}, {}
    
    # Chuẩn hóa tần suất chữ cái
    letter_freq = {letter: count/total_letters for letter, count in letter_freq.items()}
    
    # Tính tần suất từ
    word_freq = Counter(text.split())
    
    return letter_freq, word_freq

def detect_anomalies(letter_freq):
    """
    Phát hiện bất thường trong tần suất chữ cái.
    
    Args:
        letter_freq (dict): Từ điển tần suất chữ cái.
        
    Returns:
        tuple: (anomalies, naturality)
            - anomalies: Từ điển các bất thường.
            - naturality: Chỉ số tự nhiên của văn bản (0-1).
    """
    # Tần suất mong đợi của các chữ cái tiếng Anh
    expected = {
        'e': 0.12, 't': 0.09, 'a': 0.08, 'o': 0.075, 'i': 0.07,
        'n': 0.067, 's': 0.063, 'h': 0.061, 'r': 0.06, 'd': 0.043,
        'l': 0.04, 'u': 0.028, 'c': 0.028, 'm': 0.025, 'w': 0.024,
        'f': 0.022, 'g': 0.02, 'y': 0.02, 'p': 0.019, 'b': 0.015,
        'v': 0.01, 'k': 0.008, 'j': 0.002, 'x': 0.002, 'q': 0.001, 'z': 0.001
    }
    
    # Tìm các bất thường
    anomalies = {}
    total_deviation = 0
    
    for letter, exp_freq in expected.items():
        act_freq = letter_freq.get(letter, 0)
        deviation = abs(act_freq - exp_freq) / exp_freq if exp_freq > 0 else 0
        
        if deviation > 0.5:  # Sai lệch lớn hơn 50%
            anomalies[letter] = {
                'expected': exp_freq,
                'actual': act_freq,
                'deviation': deviation
            }
        
        total_deviation += abs(act_freq - exp_freq)
    
    # Tính chỉ số tự nhiên (1 = hoàn toàn tự nhiên, 0 = hoàn toàn bất thường)
    naturality = 1 - min(total_deviation / 0.5, 1.0)
    
    return anomalies, naturality

def create_frequency_plot(letter_freq, output_file):
    """
    Tạo biểu đồ tần suất chữ cái.
    
    Args:
        letter_freq (dict): Từ điển tần suất chữ cái.
        output_file (str): Đường dẫn lưu biểu đồ.
        
    Returns:
        bool: True nếu thành công, False nếu thất bại.
    """
    try:
        plt.figure(figsize=(12, 6))
        
        # Sắp xếp chữ cái theo bảng chữ cái
        letters = sorted(letter_freq.keys())
        freqs = [letter_freq[letter] for letter in letters]
        
        # Tạo biểu đồ
        bars = plt.bar(letters, freqs, color='skyblue')
        
        # Thêm tần suất chuẩn để so sánh
        expected = {
            'e': 0.12, 't': 0.09, 'a': 0.08, 'o': 0.075, 'i': 0.07,
            'n': 0.067, 's': 0.063, 'h': 0.061, 'r': 0.06, 'd': 0.043,
            'l': 0.04, 'u': 0.028, 'c': 0.028, 'm': 0.025, 'w': 0.024,
            'f': 0.022, 'g': 0.02, 'y': 0.02, 'p': 0.019, 'b': 0.015,
            'v': 0.01, 'k': 0.008, 'j': 0.002, 'x': 0.002, 'q': 0.001, 'z': 0.001
        }
        
        # Thêm các chữ cái thiếu vào expected
        expected_letters = []
        expected_freqs = []
        
        for letter in letters:
            expected_letters.append(letter)
            expected_freqs.append(expected.get(letter, 0))
            
        plt.plot(expected_letters, expected_freqs, 'ro-', alpha=0.5, label='Tần suất chuẩn')
        
        # Định dạng biểu đồ
        plt.xlabel('Chữ cái')
        plt.ylabel('Tần suất')
        plt.title('Phân tích tần suất chữ cái')
        plt.grid(axis='y', linestyle='--', alpha=0.7)
        plt.legend()
        
        # Lưu biểu đồ
        plt.tight_layout()
        plt.savefig(output_file)
        print(f"Đã lưu biểu đồ tần suất vào '{output_file}'")
        
        return True
    except Exception as e:
        print(f"Lỗi khi tạo biểu đồ: {str(e)}")
        return False

def analyze_text(file_path, plot_file=None):
    """
    Phân tích thống kê văn bản từ tệp.
    
    Args:
        file_path (str): Đường dẫn đến tệp văn bản.
        plot_file (str, optional): Đường dẫn lưu biểu đồ tần suất.
        
    Returns:
        dict: Kết quả phân tích.
    """
    try:
        # Đọc văn bản
        with open(file_path, 'r', encoding='utf-8') as f:
            text = f.read()
    except UnicodeDecodeError:
        # Thử lại với mã hóa khác
        with open(file_path, 'r', encoding='latin-1') as f:
            text = f.read()
            
    # Thống kê cơ bản
    char_count = len(text)
    letter_count = sum(1 for c in text if c.isalpha())
    digit_count = sum(1 for c in text if c.isdigit())
    space_count = sum(1 for c in text if c.isspace())
    
    # Phân tích tần suất
    letter_freq, word_freq = analyze_letter_frequency(text)
    
    # Phát hiện bất thường
    anomalies, naturality = detect_anomalies(letter_freq)
    
    # Tính entropy
    entropy = calculate_entropy(text)
    
    # Hiển thị kết quả
    print("=== PHÂN TÍCH VĂN BẢN ===")
    print(f"Tệp: {file_path}")
    print(f"Tổng số ký tự: {char_count}")
    print(f"Chữ cái: {letter_count} ({letter_count/char_count:.1%})")
    print(f"Chữ số: {digit_count} ({digit_count/char_count:.1%})")
    print(f"Khoảng trắng: {space_count} ({space_count/char_count:.1%})")
    print(f"Entropy: {entropy:.3f} bits/ký tự")
    print(f"Chỉ số tự nhiên: {naturality:.2%}")
    
    # Hiển thị cảnh báo nếu phát hiện bất thường
    if naturality < 0.8:
        print("\n[!] Cảnh báo: Văn bản có thể chứa steganography!")
        
    # Hiển thị tần suất chữ cái
    print("\nTần suất chữ cái:")
    for letter, freq in sorted(letter_freq.items()):
        print(f"{letter}: {freq:.3f}")
        
    # Hiển thị tần suất từ
    print("\nTần suất từ:")
    for word, count in sorted(word_freq.items()):
        print(f"{word}: {count}")
        
    # Tạo biểu đồ nếu được yêu cầu
    if plot_file:
        create_frequency_plot(letter_freq, plot_file)
        
    return {
        "char_count": char_count,
        "letter_count": letter_count,
        "entropy": entropy,
        "naturality": naturality,
        "anomalies": anomalies
    }

def main():
    """Hàm chính điều khiển luồng chương trình."""
    parser = argparse.ArgumentParser(description="Phân tích thống kê văn bản cho steganalysis")
    parser.add_argument("text_file", help="Đường dẫn đến tệp văn bản cần phân tích")
    parser.add_argument("--plot", help="Lưu biểu đồ tần suất chữ cái vào tệp này")
    
    if len(sys.argv) == 1:
        parser.print_help()
        return 1
        
    args = parser.parse_args()
    
    try:
        analyze_text(args.text_file, args.plot)
        return 0
    except FileNotFoundError:
        print(f"Lỗi: Không tìm thấy tệp {args.text_file}")
        return 1
    except Exception as e:
        print(f"Lỗi: {str(e)}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
